int fact(int n, int x)
{
        for (int d = 1; d < x; d++) {
                n = n * (x - d);
        }
        n = n * 10;
        int result1 = n;
        return result1;
}
int main()
{
        int integer = rand() % 10;
        int i = 3;
        int result = fact(integer, i);
        printf("result = %d\n", result);
        return 0;
}



int fibonacci(int arr[], int size);
int main()
{
        const int size = 10;
        const int n = 10;
        int arr[n];
        int result = fibonacci(arr,n);
        printf("result = %d\n", result);
        return 0;
}
int fibonacci(int arr[], int size)
{
        int fib1 = 0, fib2 = 1, fib = 0, n, i;
        fib = 1;
        for (i = 1; i <= size; i++)        {
        fib = fib2 + fib1;
        fib2 = fib1;
        fib1 = fib;
        arr[i] = fib;
        }
        return fib;
}
